package org.holoeverywhere.slider;

public class SFUIDisplayFontPath {
	public static String ULTRALIGHT = "fonts/SFUIDisplay-Ultralight.otf";
	public static String LIGHT = "fonts/SFUIDisplay-Light.otf";
	public static String MEDIUM = "fonts/SFUIDisplay-Medium.otf";
}
