/** Automatically generated file. DO NOT MODIFY */
package org.holoeverywhere;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}