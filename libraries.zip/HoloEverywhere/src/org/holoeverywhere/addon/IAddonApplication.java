
package org.holoeverywhere.addon;

import org.holoeverywhere.app.Application;

/**
 * Basic addon class which can handle application create event
 */
public abstract class IAddonApplication extends IAddonBase<Application> {
    public void onCreate() {

    }

    public void onPreCreate() {

    }
}
