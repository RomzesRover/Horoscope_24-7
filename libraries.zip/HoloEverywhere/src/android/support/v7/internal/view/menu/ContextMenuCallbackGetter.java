
package android.support.v7.internal.view.menu;

import android.view.View.OnCreateContextMenuListener;

public interface ContextMenuCallbackGetter {
    public OnCreateContextMenuListener getOnCreateContextMenuListener();
}
