package uk.co.senab.actionbarpulltorefresh.library;

import android.content.Context;
import android.graphics.Typeface;
import android.widget.Button;
import android.widget.TextView;

public class HelvFont {
	public static final HelvFont HELV_LIGHT = new HelvFont("fonts/HelveticaNeueCyr-Light.otf");
	public static final HelvFont HELV_ROMAN = new HelvFont("fonts/HelveticaNeueCyr-Roman.otf");
	public static final HelvFont HELV_MEDIUM = new HelvFont("fonts/HelveticaNeueCyr-Medium.otf");
	private final String assetName;
	private volatile Typeface typeface;

	public HelvFont(String assetName) {
		this.assetName = assetName;
	}

	public void apply(Context context, TextView textView) {
		if (typeface == null) {
			synchronized (this) {
				if (typeface == null) {
					typeface = Typeface.createFromAsset(context.getAssets(), assetName);
				}
			}
		}
		textView.setTypeface(typeface);
	}
	
	public void apply(Context context, Button button) {
		if (typeface == null) {
			synchronized (this) {
				if (typeface == null) {
					typeface = Typeface.createFromAsset(context.getAssets(), assetName);
				}
			}
		}
		button.setTypeface(typeface);
	}

}
