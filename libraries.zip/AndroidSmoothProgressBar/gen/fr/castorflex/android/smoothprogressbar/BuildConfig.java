/** Automatically generated file. DO NOT MODIFY */
package fr.castorflex.android.smoothprogressbar;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}